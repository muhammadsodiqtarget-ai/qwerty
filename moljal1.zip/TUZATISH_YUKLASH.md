# TUZATISH — fayllarni GitHub'ga TO'G'RI yuklash

## Nima bo'ldi?
Avvalgi yuklashda papkalar (app/, components/, lib/) yo'qolib,
hamma fayl bir joyga (root'ga) tushib qolgan. Shu sabab Vercel'da
"Build Failed" chiqdi. Kod to'g'ri — faqat joylashuvi buzilgan.

Quyida buni TO'G'RI qilishning 2 usuli. 1-usul eng oson va ishonchli.

======================================================================
## USUL 1 — Butun papkani birdaniga tashlash (TAVSIYA ETAMAN)
======================================================================

Sir shundaki: fayllarni BITTALAB tanlab tashlasangiz papkalar yo'qoladi.
PAPKANING O'ZINI to'liq tashlasangiz — struktura saqlanadi.

- [ ] Yangi `moljal.zip` ni yuklab oling va oching → `moljal` papkasi chiqadi

- [ ] Eski buzilgan rep`oni tozalash (ixtiyoriy, lekin toza bo'ladi):
      github.com → `qwerty` repo → Settings → eng pastda
      "Delete this repository" → o'chiring.
      Keyin yangi repo yarating: nomi `moljal`, Private.
      (Yoki eski repo'da davom etaman desangiz — 2-usulga o'ting.)

- [ ] Yangi repo sahifasida "uploading an existing file" ni bosing

- [ ] Fayl menejerini (kompyuteringizdagi papkalar oynasi) oching,
      `moljal` papkasini toping

- [ ] `moljal` papkasini OCHING. Ichida app, components, lib,
      package.json ko'rinadi.

- [ ] Endi Ctrl+A bosib ICHIDAGI HAMMASINI belgilang
      (app, components, lib papkalari VA package.json kabi fayllar)

- [ ] Belgilangan narsalarni GitHub oynasidagi
      "Drag files here" zonasiga BIRDANIGA sudrab tashlang.

      MUHIM: papkalar (app, components, lib) ham tashlanishi shart.
      Brauzer papkalarni ichidagi fayllari bilan qabul qiladi.

- [ ] Yuklanganidan keyin GitHub oynasida quyidagicha ko'rinishi kerak
      (fayllar YONIDA papka belgilari bilan):
         app / ...
         components / ...
         lib / ...
         package.json
         middleware.js
      Agar shunday ko'rinsa — TO'G'RI. Agar app/page.jsx o'rniga
      shunchaki page.jsx ko'rinsa — noto'g'ri, qaytadan.

- [ ] "Commit changes" bosing

======================================================================
## USUL 2 — GitHub Desktop orqali (agar Usul 1 baribir buzsa)
======================================================================

Brauzer ba'zan papka tashlashni qo'llamaydi. Unda:

- [ ] desktop.github.com dan "GitHub Desktop" dasturini o'rnating
- [ ] Kirib, "File → Add Local Repository" NI EMAS,
      "File → New Repository" ni tanlang, nomi `moljal`
- [ ] Yaratilgan papkani oching (dastur joyini ko'rsatadi)
- [ ] `moljal.zip` dan chiqqan hamma narsani (app, components, lib,
      package.json ...) shu papka ichiga NUSXALANG
- [ ] GitHub Desktop'da o'zgarishlar ko'rinadi → pastga "Summary" yozing
      (masalan "birinchi yuklash") → "Commit to main"
- [ ] Yuqorida "Publish repository" → Private belgilab, Publish

Bu usul papkalarni 100% to'g'ri saqlaydi.

======================================================================
## KEYIN — Vercel'da qayta deploy
======================================================================

- [ ] Fayllar to'g'ri yuklangach, Vercel avtomatik yangi deploy boshlaydi.
      Agar boshlamasa: Vercel → loyiha → Deployments → "..." → Redeploy

- [ ] Bu safar "Build Failed" o'rniga muvaffaqiyatli o'tishi kerak

- [ ] Agar yangi repo (`moljal`) yaratgan bo'lsangiz, Vercel'da
      uni qayta import qilishingiz kerak bo'lishi mumkin:
      Vercel → Add New → Project → `moljal` → Import → Deploy

Muammo chiqsa — build log'ning skrinshotini menga tashlang.
