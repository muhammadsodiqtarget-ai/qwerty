import { kvGet, kvSet } from '@/lib/db';
import { dailyInsights } from '@/lib/meta';
import { sendTelegram, formatDailyReport } from '@/lib/telegram';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function GET(req) {
  const auth = req.headers.get('authorization');
  const isVercelCron = auth === `Bearer ${process.env.CRON_SECRET}`;
  if (process.env.CRON_SECRET && !isVercelCron) return new Response('Unauthorized', { status: 401 });

  const ads = (await kvGet('ads')) || { projects: [] };
  const d = new Date(Date.now() - 24 * 3600 * 1000);
  const y = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  const results = [];

  for (const p of ads.projects || []) {
    if (!p.chatId || !p.act || !p.business) { results.push({ project: p.name, skipped: true }); continue; }
    try {
      const days = await dailyInsights(p.business, p.act, y, y);
      const day = days[0] || { date: y, spend: 0, impressions: 0, clicks: 0, ctr: 0, leads: 0, cpl: 0 };
      await sendTelegram(p.chatId, formatDailyReport(p.name, p.currency || 'USD', day));
      results.push({ project: p.name, sent: true });
    } catch (e) {
      results.push({ project: p.name, error: String(e.message || e) });
    }
  }
  await kvSet('last_cron', { at: new Date().toISOString(), results });
  return Response.json({ ok: true, date: y, results });
}
