import { listAccounts } from '@/lib/meta';
export const dynamic = 'force-dynamic';
export async function GET() {
  try { return Response.json({ accounts: await listAccounts() }); }
  catch (e) { return Response.json({ error: String(e.message || e) }, { status: 500 }); }
}
