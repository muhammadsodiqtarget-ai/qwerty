import { dailyInsights } from '@/lib/meta';
export const dynamic = 'force-dynamic';
export async function GET(req) {
  const u = new URL(req.url);
  const business = u.searchParams.get('business');
  const act = u.searchParams.get('act');
  const since = u.searchParams.get('since');
  const until = u.searchParams.get('until');
  if (!business || !act || !since || !until) return Response.json({ error: 'business, act, since, until required' }, { status: 400 });
  try { return Response.json({ days: await dailyInsights(business, act, since, until) }); }
  catch (e) { return Response.json({ error: String(e.message || e) }, { status: 500 }); }
}
