import { kvGet, kvSet } from '@/lib/db';

export async function GET(req) {
  const key = new URL(req.url).searchParams.get('key');
  if (!key) return Response.json({ error: 'key required' }, { status: 400 });
  const value = await kvGet(key);
  return Response.json({ key, value });
}

export async function POST(req) {
  const { key, value } = await req.json();
  if (!key) return Response.json({ error: 'key required' }, { status: 400 });
  const res = await kvSet(key, value);
  return Response.json({ ok: true, ...res });
}
