export async function POST(req) {
  const { password } = await req.json();
  if (!process.env.ACCESS_PASSWORD) return Response.json({ error: 'ACCESS_PASSWORD sozlanmagan' }, { status: 500 });
  if (password !== process.env.ACCESS_PASSWORD) return Response.json({ error: 'Parol noto\u2018g\u2018ri' }, { status: 401 });
  const data = new TextEncoder().encode(password + '|moljal');
  const hash = await crypto.subtle.digest('SHA-256', data);
  const token = Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('');
  return new Response(JSON.stringify({ ok: true }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'Set-Cookie': `mj_auth=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000; Secure`,
    },
  });
}
