'use client';
import { useState } from 'react';

export default function Login() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true); setError('');
    const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    if (r.ok) { window.location.href = '/'; return; }
    const j = await r.json().catch(() => ({}));
    setError(j.error || 'Kirishda xatolik'); setLoading(false);
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 380 }} className="fade-in">
        <div className="thread-thick" style={{ borderRadius: 3, marginBottom: 28 }} />
        <h1 className="display" style={{ fontWeight: 900, fontSize: 34, letterSpacing: '-1px' }}>Mo&#699;ljal</h1>
        <p style={{ color: 'var(--ink-soft)', marginTop: 6, marginBottom: 28, fontSize: 15 }}>
          Agentlik ishlari: doska, kalendar va Meta Ads hisobotlari — bitta joyda.
        </p>
        <form onSubmit={submit} className="card" style={{ padding: 22 }}>
          <label className="label" htmlFor="pw">Jamoa paroli</label>
          <input id="pw" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" autoFocus />
          {error && <p style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</p>}
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 16 }} disabled={loading}>
            {loading ? 'Kirilmoqda…' : 'Kirish'}
          </button>
        </form>
      </div>
    </div>
  );
}
