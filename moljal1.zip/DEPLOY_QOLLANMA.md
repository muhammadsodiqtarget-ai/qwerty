# Mo'ljal — saytni internetga chiqarish qo'llanmasi

Bu qo'llanma sizni noldan tayyor, ishlaydigan saytgacha olib boradi.
Meta Ads bo'limi hozircha token'siz turadi (keyin qo'shamiz) — qolgan hammasi to'liq ishlaydi.

Jami vaqt: ~15 daqiqa. Har qadamni bajargach, oldidagi katakchani belgilab keting.

---

## TAYYORGARLIK

- [ ] `moljal.zip` faylini kompyuterga yuklab oling
- [ ] Uni oching (o'ng tugma → "Extract / Chiqarish"). Ichida `moljal` nomli papka bo'ladi
- [ ] GitHub akkauntingiz borligini tekshiring (yo'q bo'lsa github.com dan bepul oching)
- [ ] Vercel akkauntingiz borligini tekshiring (bor — MCP ulangan)

---

## 1-QADAM — GitHub'ga yuklash (~5 daqiqa)

- [ ] github.com ga kiring
- [ ] O'ng yuqoridagi "+" belgisi → "New repository" ni bosing
- [ ] "Repository name" ga yozing: `moljal`
- [ ] Pastroqda "Private" ni tanlang (muhim — kod maxfiy qolsin)
- [ ] Yashil "Create repository" tugmasini bosing
- [ ] Ochilgan sahifada "uploading an existing file" havolasini bosing
      (yoki "Add file" → "Upload files")
- [ ] Kompyuterda `moljal` papkasini OCHING, ICHIDAGI hamma narsani
      (app, components, lib, package.json va boshqalar) belgilab,
      GitHub oynasiga sudrab (drag) tashlang

      DIQQAT: `moljal` papkasining O'ZINI emas, ICHIDAGI fayllarni tashlang.
      Ya'ni GitHub'da yuqorida to'g'ridan-to'g'ri "app", "components", "lib",
      "package.json" ko'rinishi kerak.

- [ ] Pastda yashil "Commit changes" tugmasini bosing
- [ ] Fayllar yuklanguncha kuting (bir necha soniya)

---

## 2-QADAM — Vercel'ga ulash va birinchi deploy (~3 daqiqa)

- [ ] vercel.com ga kiring
- [ ] "Add New..." → "Project" ni bosing
- [ ] "Import Git Repository" ro'yxatidan `moljal` ni toping → "Import"
- [ ] Hech narsani o'zgartirmang (Framework: Next.js o'zi aniqlanadi)
- [ ] "Deploy" tugmasini bosing
- [ ] 1-2 daqiqa kuting. "Congratulations" chiqadi va sayt manzili paydo bo'ladi
      (masalan: moljal-xxxx.vercel.app)

  Eslatma: hozir saytga kirsangiz "parol noto'g'ri" turishi mumkin —
  chunki hali parolni kiritmadik. 3-qadamda hal bo'ladi.

---

## 3-QADAM — Baza ulash (ma'lumot saqlanib qolishi uchun) (~3 daqiqa)

Busiz sayt ishlaydi, lekin har yangilanishda doska ma'lumotlari o'chadi.
Shuning uchun ulash SHART.

- [ ] Vercel'da `moljal` loyihasini oching
- [ ] Yuqoridagi menyudan "Storage" bo'limiga o'ting
- [ ] "Create Database" → ro'yxatdan "Neon" (Postgres) ni tanlang
- [ ] "Continue" / "Create" bosib, so'ralgan narsalarni tasdiqlang
      (bepul reja yetarli)
- [ ] Yaratilgach, uni `moljal` loyihasiga "Connect" qiling
- [ ] Bu avtomatik `DATABASE_URL` degan kalitni loyihaga qo'shadi

---

## 4-QADAM — Kirish parolini o'rnatish (~2 daqiqa)

- [ ] Vercel'da `moljal` → "Settings" → chap menyudan "Environment Variables"
- [ ] "Key" maydoniga yozing: ACCESS_PASSWORD
- [ ] "Value" maydoniga o'zingiz o'ylagan jamoa parolini yozing
      (masalan: Moljal2026! — buni jamoaga aytasiz)
- [ ] "Save" bosing

---

## 5-QADAM — Qayta deploy (o'zgarishlar kuchga kirishi uchun) (~2 daqiqa)

- [ ] Vercel'da `moljal` → yuqoridan "Deployments" bo'limi
- [ ] Eng yuqoridagi (oxirgi) deploy yonidagi "..." (uch nuqta) → "Redeploy"
- [ ] Chiqqan oynada yana "Redeploy" ni tasdiqlang
- [ ] 1-2 daqiqa kuting

---

## TAYYOR! Tekshirish

- [ ] Sayt manzilini oching (moljal-xxxx.vercel.app)
- [ ] O'rnatgan parolingiz bilan kiring
- [ ] Doska, Kalendar, Dashboard, Jamoa bo'limlari ishlayotganini ko'ring
- [ ] Jamoa bo'limidan bir-ikki hodim qo'shib sinab ko'ring
- [ ] Doskaga vazifa qo'shib, sahifani yangilang — vazifa saqlanib turishi kerak
      (agar saqlanmasa — 3-qadam, baza ulanmagan)

- [ ] Sayt manzilini jamoangizga (va parolni) ulashing — hammasi shu havola
      orqali birga ishlaydi

---

## KEYINGI BOSQICH — Meta Ads'ni jonlantirish (token tayyor bo'lgach)

Elegan Generator va pipls.andijan token'lari qo'lga kelganda:

- [ ] Vercel → Settings → Environment Variables ga qo'shing:
      - META_TOKENS  →  {"Elegan Generator":"EAA...","pipls.andijan":"EAA..."}
      - TELEGRAM_BOT_TOKEN  →  @BotFather bergan token
      - CRON_SECRET  →  istalgan uzun tasodifiy satr (30+ belgi)
- [ ] Yana bir marta Redeploy (5-qadam kabi)
- [ ] Saytda Meta Ads → "Loyiha qo'shish" → akkauntlar ro'yxati chiqadi

---

## Muammo chiqsa

Istalgan qadamda to'xtab qolsangiz — o'sha ekranning skrinshotini oling
va menga (chatdagi Claude'ga) yuboring. Aniq nima bosishni ko'rsataman.
